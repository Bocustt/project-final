# VSGA-Kominfo-2021-FinalProject
Final project untuk Peserta VSGA

Ini merupakan File Final Project yang akan dibuat oleh Siswa - Siswi Pelatihan DTS-VSGA untuk Kompetensi Junior Web Developer, dimana pada aplikasi sederhana ini yang merupakan Aplikasi PERPUSTAKAAN UMUM.

Aplikasi Asli bersumber dari Kominfo dan panitia.

Aplikasi ini merupakan modifikasi dari aplikasi asli kominfo yang dibuat oleh Stendy B. Sakur dari Politeknik Negeri Nusa Utara. Aplikasinya dapat di lihat pada situs: https:/vsga.sakurtek.com, perubahan yang dilakukan dari file aslinya adalah:

User interface menggunakan Bootstrap 4.5.3, walaupun desainya dibuat sangat sederhana.
Backendnya menggunakan PHP yang dibuat dengan menggunakan konsep Moduler, dimana semua proses yang berhubungan dengan PHP dan Database dibuat menggunakan fungsi yang semua fungsinya di masukkan dalam satu file yaitu: modul.php pada folder modul. Sehingga untuk menggunakan fungsi tersebut maka file: modul/modul.php harus di ikutsertakan dalam file yang akan mengguakan fungsinya dengan menggunakan perintah: require_once();
Beberapa validasi form menggunakan bootstrap.
Fokus utama adalah bagaimana siswa dapat merancang User interface baik menggunakan CSS native ataupun framework. Selain itu Fokus pada Backend siswa dapat membuat Aplikasi dengan menerapkan fungsi yang sudah dipelajari, dimana seluruh fungsi disimpan pada satu file yaitu modul.php

Stendy B. Sakur,

Dosen Politeknik Negeri Nusa Utara - Tahuna, Manado

<?php

require_once "modul/modul.php";
getLogout();

?>
<?php

// mengikutsertakan modul.php yang telah dibuat
// dengan menggunakan fungsi/prosedur
require_once "../modul/modul.php";

// menjalankan fungsi processDeleteUser()
// dengan parameter $_GET['id']
processDeleteUser ($_GET['id']);

?>